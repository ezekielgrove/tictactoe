package com.ezekielgrove.tictactoe;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

public class GameActivity extends AppCompatActivity implements View.OnClickListener {

    private char marker;
    private int mode;
    private int size;
    private Game game;
    private boolean win = false, draw = false;
    private LinearLayout boardLayout, messageLayout;
    private ImageView zeroZero, zeroOne, zeroTwo, zeroThree, zeroFour,
            oneZero, oneOne, oneTwo, oneThree, oneFour,
            twoZero, twoOne, twoTwo, twoThree, twoFour,
            threeZero, threeOne, threeTwo, threeThree, threeFour,
            fourZero, fourOne, fourTwo, fourThree, fourFour;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent = getIntent();

        mode = intent.getIntExtra("MODE", 0);
        size = intent.getIntExtra("SIZE", 3);
        marker = intent.getCharExtra("MARKER", 'x');

        setContentView(size == 3 ? R.layout.activity_game_three : R.layout.activity_game_five);

        game = new Game(size, marker);

        boardLayout = findViewById(R.id.board);
        messageLayout = findViewById(R.id.message);

        zeroZero = findViewById(R.id.zero_zero);
        zeroOne = findViewById(R.id.zero_one);
        zeroTwo = findViewById(R.id.zero_two);

        oneZero = findViewById(R.id.one_zero);
        oneOne = findViewById(R.id.one_one);
        oneTwo = findViewById(R.id.one_two);

        twoZero = findViewById(R.id.two_zero);
        twoOne = findViewById(R.id.two_one);
        twoTwo = findViewById(R.id.two_two);

        zeroZero.setOnClickListener(this);
        zeroOne.setOnClickListener(this);
        zeroTwo.setOnClickListener(this);

        oneZero.setOnClickListener(this);
        oneOne.setOnClickListener(this);
        oneTwo.setOnClickListener(this);

        twoZero.setOnClickListener(this);
        twoOne.setOnClickListener(this);
        twoTwo.setOnClickListener(this);
        if (size == 5) {
            zeroThree = findViewById(R.id.zero_three);
            zeroFour = findViewById(R.id.zero_four);

            oneThree = findViewById(R.id.one_three);
            oneFour = findViewById(R.id.one_four);

            twoThree = findViewById(R.id.two_three);
            twoFour = findViewById(R.id.two_four);

            threeZero = findViewById(R.id.three_zero);
            threeOne = findViewById(R.id.three_one);
            threeTwo = findViewById(R.id.three_two);
            threeThree = findViewById(R.id.three_three);
            threeFour = findViewById(R.id.three_four);

            fourZero = findViewById(R.id.four_zero);
            fourOne = findViewById(R.id.four_one);
            fourTwo = findViewById(R.id.four_two);
            fourThree = findViewById(R.id.four_three);
            fourFour = findViewById(R.id.four_four);

            zeroThree.setOnClickListener(this);
            zeroFour.setOnClickListener(this);

            oneThree.setOnClickListener(this);
            oneFour.setOnClickListener(this);

            twoThree.setOnClickListener(this);
            twoFour.setOnClickListener(this);

            threeZero.setOnClickListener(this);
            threeOne.setOnClickListener(this);
            threeTwo.setOnClickListener(this);
            threeThree.setOnClickListener(this);
            threeFour.setOnClickListener(this);

            fourZero.setOnClickListener(this);
            fourOne.setOnClickListener(this);
            fourTwo.setOnClickListener(this);
            fourThree.setOnClickListener(this);
            fourFour.setOnClickListener(this);
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.zero_zero:
                if (!this.game.isMarked(0, 0)) {
                    this.game.placeMark(0, 0);
                    this.zeroZero.setImageResource(this.game.getMarker() == 'x' ?
                            R.drawable.background_x : R.drawable.background_o);
                } else {
                    error();
                }
                break;
            case R.id.zero_one:
                if (!this.game.isMarked(0, 1)) {
                    this.game.placeMark(0, 1);
                    this.zeroOne.setImageResource(this.game.getMarker() == 'x' ?
                            R.drawable.background_x : R.drawable.background_o);
                } else {
                    error();
                }
                break;
            case R.id.zero_two:
                if (!this.game.isMarked(0, 2)) {
                    this.game.placeMark(0, 2);
                    this.zeroTwo.setImageResource(this.game.getMarker() == 'x' ?
                            R.drawable.background_x : R.drawable.background_o);
                } else {
                    error();
                }
                break;
            //  <if board size = 5> ===========================================
            case R.id.zero_three:
                if (!this.game.isMarked(0, 3)) {
                    this.game.placeMark(0, 3);
                    this.zeroThree.setImageResource(this.game.getMarker() == 'x' ?
                            R.drawable.background_x : R.drawable.background_o);
                } else {
                    error();
                }
                break;
            case R.id.zero_four:
                if (!this.game.isMarked(0, 4)) {
                    this.game.placeMark(0, 4);
                    this.zeroFour.setImageResource(this.game.getMarker() == 'x' ?
                            R.drawable.background_x : R.drawable.background_o);
                } else {
                    error();
                }
                break;
            //  </if board size = 5> ===========================================
            case R.id.one_zero:
                if (!this.game.isMarked(1, 0)) {
                    this.game.placeMark(1, 0);
                    this.oneZero.setImageResource(this.game.getMarker() == 'x' ?
                            R.drawable.background_x : R.drawable.background_o);
                } else {
                    error();
                }
                break;
            case R.id.one_one:
                if (!this.game.isMarked(1, 1)) {
                    this.game.placeMark(1, 1);
                    this.oneOne.setImageResource(this.game.getMarker() == 'x' ?
                            R.drawable.background_x : R.drawable.background_o);
                } else {
                    error();
                }
                break;
            case R.id.one_two:
                if (!this.game.isMarked(1, 2)) {
                    this.game.placeMark(1, 2);
                    this.oneTwo.setImageResource(this.game.getMarker() == 'x' ?
                            R.drawable.background_x : R.drawable.background_o);
                } else {
                    error();
                }
                break;
            //  <if board size = 5> ===========================================
            case R.id.one_three:
                if (!this.game.isMarked(1, 3)) {
                    this.game.placeMark(1, 3);
                    this.oneThree.setImageResource(this.game.getMarker() == 'x' ?
                            R.drawable.background_x : R.drawable.background_o);
                } else {
                    error();
                }
                break;
            case R.id.one_four:
                if (!this.game.isMarked(1, 4)) {
                    this.game.placeMark(1, 4);
                    this.oneFour.setImageResource(this.game.getMarker() == 'x' ?
                            R.drawable.background_x : R.drawable.background_o);
                } else {
                    error();
                }
                break;
            //  </if board size = 5> ===========================================
            case R.id.two_zero:
                if (!this.game.isMarked(2, 0)) {
                    this.game.placeMark(2, 0);
                    this.twoZero.setImageResource(this.game.getMarker() == 'x' ?
                            R.drawable.background_x : R.drawable.background_o);
                } else {
                    error();
                }
                break;
            case R.id.two_one:
                if (!this.game.isMarked(2, 1)) {
                    this.game.placeMark(2, 1);
                    this.twoOne.setImageResource(this.game.getMarker() == 'x' ?
                            R.drawable.background_x : R.drawable.background_o);
                } else {
                    error();
                }
                break;
            case R.id.two_two:
                if (!this.game.isMarked(2, 2)) {
                    this.game.placeMark(2, 2);
                    this.twoTwo.setImageResource(this.game.getMarker() == 'x' ?
                            R.drawable.background_x : R.drawable.background_o);
                } else {
                    error();
                }
                break;
            //  <if board size = 5> ===========================================
            case R.id.two_three:
                if (!this.game.isMarked(2, 3)) {
                    this.game.placeMark(2, 3);
                    this.twoThree.setImageResource(this.game.getMarker() == 'x' ?
                            R.drawable.background_x : R.drawable.background_o);
                } else {
                    error();
                }
                break;
            case R.id.two_four:
                if (!this.game.isMarked(2, 4)) {
                    this.game.placeMark(2, 4);
                    this.twoFour.setImageResource(this.game.getMarker() == 'x' ?
                            R.drawable.background_x : R.drawable.background_o);
                } else {
                    error();
                }
                break;
            case R.id.three_zero:
                if (!this.game.isMarked(3, 0)) {
                    this.game.placeMark(3, 0);
                    this.threeZero.setImageResource(this.game.getMarker() == 'x' ?
                            R.drawable.background_x : R.drawable.background_o);
                } else {
                    error();
                }
                break;
            case R.id.three_one:
                if (!this.game.isMarked(3, 1)) {
                    this.game.placeMark(3, 1);
                    this.threeOne.setImageResource(this.game.getMarker() == 'x' ?
                            R.drawable.background_x : R.drawable.background_o);
                } else {
                    error();
                }
                break;
            case R.id.three_two:
                if (!this.game.isMarked(3, 2)) {
                    this.game.placeMark(3, 2);
                    this.threeTwo.setImageResource(this.game.getMarker() == 'x' ?
                            R.drawable.background_x : R.drawable.background_o);
                } else {
                    error();
                }
                break;
            case R.id.three_three:
                if (!this.game.isMarked(3, 3)) {
                    this.game.placeMark(3, 3);
                    this.threeThree.setImageResource(this.game.getMarker() == 'x' ?
                            R.drawable.background_x : R.drawable.background_o);
                } else {
                    error();
                }
                break;
            case R.id.three_four:
                if (!this.game.isMarked(3, 4)) {
                    this.game.placeMark(3, 4);
                    this.threeFour.setImageResource(this.game.getMarker() == 'x' ?
                            R.drawable.background_x : R.drawable.background_o);
                } else {
                    error();
                }
                break;
            case R.id.four_zero:
                if (!this.game.isMarked(4, 0)) {
                    this.game.placeMark(4, 0);
                    this.fourZero.setImageResource(this.game.getMarker() == 'x' ?
                            R.drawable.background_x : R.drawable.background_o);
                } else {
                    error();
                }
                break;
            case R.id.four_one:
                if (!this.game.isMarked(4, 1)) {
                    this.game.placeMark(4, 1);
                    this.fourOne.setImageResource(this.game.getMarker() == 'x' ?
                            R.drawable.background_x : R.drawable.background_o);
                } else {
                    error();
                }
                break;
            case R.id.four_two:
                if (!this.game.isMarked(4, 2)) {
                    this.game.placeMark(4, 2);
                    this.fourTwo.setImageResource(this.game.getMarker() == 'x' ?
                            R.drawable.background_x : R.drawable.background_o);
                } else {
                    error();
                }
                break;
            case R.id.four_three:
                if (!this.game.isMarked(4, 3)) {
                    this.game.placeMark(4, 3);
                    this.fourThree.setImageResource(this.game.getMarker() == 'x' ?
                            R.drawable.background_x : R.drawable.background_o);
                } else {
                    error();
                }
                break;
            case R.id.four_four:
                if (!this.game.isMarked(4, 4)) {
                    this.game.placeMark(4, 4);
                    this.fourFour.setImageResource(this.game.getMarker() == 'x' ?
                            R.drawable.background_x : R.drawable.background_o);
                } else {
                    error();
                }
                break;
            //  </if board size = 5> ===========================================
        }
        this.gameCycle();
    }

    public void gameCycle() {
        try {
            if (this.game.globalCheck()) {
                win = true;
                Toast.makeText(this,
                        "We have a winner! Congrats!", Toast.LENGTH_SHORT).show();
            } else if (this.game.isFull()) {
                draw = true;
                Toast.makeText(this, "Appears we have a draw!", Toast.LENGTH_SHORT).show();
            } else {
                game.changePlayer();
            }
            if (win || draw)
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        onBackPressed();
                    }
                }, 2500L);
        } catch (Exception e) {
            Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void error() {
        Toast.makeText(this, "Invalid move", Toast.LENGTH_SHORT).show();
        return;
    }

    private void showDialog(String message) {

    }
}
