package com.ezekielgrove.tictactoe;

/**
 * Created by Aregbe on 4/5/2018.
 */

public class Game {
    private int size;
    private char marker;
    private char[][] board;

    public Game(int size, char marker) {
        this.size = size;
        this.marker = marker;
        board = new char[this.size][size];
        init();
    }

    public void init() {
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                board[i][j] = 'n';
            }
        }
    }

    public char getMarker() {
        return this.marker;
    }

    public boolean isMarked(int row, int col) {
        return board[row][col] != 'n';
    }

    public boolean isFull() {
        boolean isFull = true;

        for (int i = 0; i < this.size; i++) {
            for (int j = 0; j < this.size; j++) {
                if (board[i][j] == 'n') {
                    isFull = false;
                }
            }
        }

        return isFull;
    }

    public boolean globalCheck() {
        return columnCheck() || rowCheck() || diagnonalRight() || diagnonalLeft();
    }

    public boolean columnCheck() {
        for (int i = 0; i < this.size; i++) {
            for (int j = 0; j <= this.size / 2; j++) {
                if (board[i][j] != 'n' && j + 2 < this.size &&
                        ((board[i][j] == board[i][j + 1] && board[i][j] == board[i][j + 2])))
                    return true;
            }
        }
        return false;
    }

    private boolean diagnonalRight() {
        for (int i = 0; i < this.size; i++) {
            for (int j = 0; j <= this.size / 2; j++) {
                if (board[i][j] != 'n' && j + 2 < this.size && i + 2 < this.size &&
                        ((board[i][j] == board[i + 1][j + 1] && board[i][j] == board[i + 2][j + 2])))
                    return true;
            }
        }
        return false;
    }

    private boolean diagnonalLeft() {
        for (int i = 0; i < this.size; i++) {
            for (int j = size - 1; j > size / 2; j--) {
                if (board[i][j] != 'n' && j - 2 >= 0 && i + 2 < this.size &&
                        ((board[i][j] == board[i + 1][j - 1] && board[i][j] == board[i + 2][j - 2])))
                    return true;
            }
        }
        return false;
    }

    public boolean rowCheck() {
        for (int i = 0; i < this.size; i++) {
            for (int j = 0; j <= this.size / 2; j++) {
                if (board[j][i] != 'n' && j + 2 < this.size &&
                        ((board[j][i] == board[j + 1][i] && board[j][i] == board[j + 2][i])))
                    return true;
            }
        }
        return false;
    }

    public void changePlayer() {
        if (this.marker == 'x') {
            this.marker = 'o';
        } else {
            this.marker = 'x';
        }
    }


    public boolean placeMark(int row, int col) {

        if ((row >= 0) && (row < this.size)) {
            if ((col >= 0) && (col < this.size)) {
                if (board[row][col] == 'n') {
                    board[row][col] = this.marker;
                    return true;
                }
            }
        }

        return false;
    }

}
