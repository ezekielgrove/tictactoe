package com.ezekielgrove.tictactoe;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {

    private ToggleButton boardSize, marker, mode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mode = findViewById(R.id.mode);
        marker = findViewById(R.id.marker);
        boardSize = findViewById(R.id.boardSize);
    }

    public void play(View view) {
        Intent intent = new Intent(this, GameActivity.class);
        intent.putExtra("MODE", mode.isChecked() ? 1 : 0);
        intent.putExtra("MARKER", marker.isChecked() ? 'o' : 'x');
        intent.putExtra("SIZE", boardSize.isChecked() ? 5 : 3);

        startActivity(intent);
    }
}
